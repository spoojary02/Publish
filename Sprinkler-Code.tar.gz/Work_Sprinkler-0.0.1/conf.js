var bodyParser = require('body-parser');
var fs = require('fs');
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

var weather = null;

const CONFIGFILEPATH = './conf.html';
const URLPATH = '/conf'

function standardOutput(res) {
    fs.readFile('./conf.html', 'ASCII', function(err, data) {  
            if (err){
                console.log('error loading conf.html: ' + err);
                return;
            }

            fs.readFile('./location.txt', 'ASCII', function(err, dataCurLoc) {  
                if (err){
                    console.log('error loading location ' + err);
                    return;
                } 
            
                const dom = new JSDOM(data);
                dom.window.document.querySelector("#currentLocationText").innerHTML = dataCurLoc;
                res.send(dom.serialize());
            });
        });
}

module.exports.init = function(app, weatherGiven) {
    weather = weatherGiven;

    app.use(bodyParser.urlencoded({ extended: true }));     
    app.use(bodyParser.json());
    
    app.get(URLPATH, function getConfPage(req, res) {
       standardOutput(res);
    });

    app.post(URLPATH, function postProcess(req, res) {
        if(req.body.submit == "Set Wifi") {
            console.log('Setting Wifi: Username(' + req.body.username +
             '), Password(' + req.body.password + ')');
            standardOutput(res);
        } else if(req.body.submit == "Test Your Location") {
            if(req.body.location.length > 0)
                console.log('Test your location @: ' + req.body.location);
                weather.testLocation(req.body.location, res);
        } else if(req.body.submit == "Set to this Location") {
            console.log('Setting Location @: ' + req.body.location);
            fs.writeFileSync('./location.txt', req.body.location);
            standardOutput(res);
        } else if(req.body.submit == "Reboot") {
            console.log('Reboot system');
            standardOutput(res);
        } else {
            res.send("Oops, error")
        }       
    });
}