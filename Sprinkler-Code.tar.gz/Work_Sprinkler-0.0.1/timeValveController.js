var gpioController = ''

var weather = null;
var currentList = [];
var oldList = [];
var isValveOnList = [];

var gpio = null;
var clientID

var TARGETWEATHER = ['Light Rain', 'T-Storms'];
const VALIDPINS = [11, 13, 15, 29, 31, 33, 35, 37, 32, 36, 38, 40];
// time control functions
function timeStrToNumArray(str) {
    data = str.split(':');
    data[0] = parseInt(data[0]);
    data[1] = parseInt(data[1]);
    return data
}

function compareTimeArray(time0, time1) { // does time0 <= time1 ??
    ret = null;

    if(time1[0] > time0[0]){ //should've done it recursively, anyone?
        ret = true;
    } else if (time1[0] < time0[0]) {
        ret = false;
    } else {
        if(time1[1] >= time0[1]) {
            ret = true;
        } else if (time1[1] < time0[1]) {
            ret = false;
        }
    }
    return ret;
};

function timeStrInBetween(afterTime, currentTime, beforeTime) {
    after = timeStrToNumArray(afterTime);
    current = timeStrToNumArray(currentTime);
    before = timeStrToNumArray(beforeTime);

    if(!compareTimeArray(after, before)) {
        before[0] += 24; //if the time to stop is in the next day, add 24 (1 day)
    }

    return (compareTimeArray(after, current) && compareTimeArray(current, before));
};

//Module exportables
module.exports.init = function(weatherGiven, gpioController) {
    weather = weatherGiven;
    gpio = gpioController;
    clientID = gpio.initInstance()
};
module.exports.alert = function(newList) {
    currentList = newList;
};

//Loop Test function
function testTime() {
    var currentDate = new Date();
    var currentDateStr = (currentDate.getHours() + ':'+ currentDate.getMinutes() + ':' + currentDate.getSeconds());

    for(var i = 0; i < currentList.length && gpio != null; i++) {
        let validDays = currentList[i].days.split(',');
        if(timeStrInBetween(currentList[i].timeStart, currentDateStr, currentList[i].timeEnd,) && 
            (validDays.indexOf(currentDate.getDay() + '') >= 0)) {
            if(!weather.inTheNextDays(currentList[i].rainVal, TARGETWEATHER)){
                gpio.turnOn(clientID, parseInt(currentList[i].valveNum));
            } else {
                //console.log('Watering canceled due to impending rain. #' + currentList[i].valveNum);
                gpio.turnOff(clientID, parseInt(currentList[i].valveNum));
            }
            // console.log('Yes at: ' + i);
        } else {
            gpio.turnOff(clientID, parseInt(currentList[i].valveNum));
        }
    }
};

function removeOutSet() {
    for(var i = 0; i < VALIDPINS.length && gpio != null; i++) {
        let isOn = false;
        for(var j = 0; j < currentList.length && !isOn; j++)
            if(currentList[j].valveNum == (VALIDPINS[i] + ""))
                isOn = true;
        if(!isOn)
            gpio.turnOff(clientID, VALIDPINS[i]);
    }
}

setInterval(testTime, 1000);
setInterval(removeOutSet, 1000);
