var gpio = require('rpi-gpio');

var isOnListList = [];
var currentlyOnList = [];
var tmpRemoveList = [];
var isResettingDoNotDisturb = false;

module.exports.initInstance = function() {
    let index = isOnListList.length;
    isOnListList[index] = [];
    return index;
}

module.exports.turnOn = function(clientID, pinNum) {
    if(isOnListList[clientID].indexOf(pinNum) < 0) {
        isOnListList[clientID].push(pinNum);
    }
}

module.exports.turnOff = function(clientID, pinNum) {
    var i = isOnListList[clientID].indexOf(pinNum);
    if(i >= 0) {
        isOnListList[clientID].splice(i, 1);
    }
}

function turnPinOnIndex(i) {
    gpio.setup(currentlyOnList[i], gpio.DIR_LOW, function() {
        var date = new Date();
        console.log('INDEX~~Turning On Pin #' + currentlyOnList[this.index] + ' at ' + date.getHours() + ':' + date.getMinutes());
        if(this.index == currentlyOnList.length - 1) {
            isResettingDoNotDisturb = false;
        }
        }.bind({index: i}));
}

function turnPinOn(pinNum, index) {
    gpio.setup(pinNum, gpio.DIR_LOW, function() {
        var date = new Date();
        console.log('Turning On Pin #' + currentlyOnList[this.i] + ' at ' + date.getHours() + ':' + date.getMinutes());
        }.bind({i: index}));
}

function setup() {
    for(var i = 0; i < currentlyOnList.length; i++) {
        turnPinOnIndex(i)
    }
    if(currentlyOnList.length == 0) {
        isResettingDoNotDisturb = false;
    }
};

function resetWithNew() {
    for(var i = 0; i < tmpRemoveList.length; i++) {
        var index = currentlyOnList.indexOf(tmpRemoveList[i]);
        gpio.write(parseInt(tmpRemoveList[i]), true, function(err) {
            if(err) throw err;
            let date = new Date();
            console.log('Turning Off Pin #' + tmpRemoveList[this.index] + ' at ' + date.getHours() + ':' + date.getMinutes());
            if(index >= 0)
                currentlyOnList.splice(index, 1);
            if(this.index == tmpRemoveList.length - 1)
                gpio.destroy(setup);
            }.bind({index: i}));
    }
}

function checkNewPin() {
    if(!isResettingDoNotDisturb)
        for(var i = 0; i < isOnListList.length; i++)
            for(var j = 0; j < isOnListList[i].length; j++)
                if(currentlyOnList.indexOf(isOnListList[i][j]) < 0) {
                    var nextPos = currentlyOnList.length;
                    currentlyOnList[nextPos] = isOnListList[i][j];
                    turnPinOn(isOnListList[i][j], nextPos);
                }
}

function checkOldPin() {
    if(!isResettingDoNotDisturb) {
        tmpRemoveList = [];
        for(var i = 0; i < currentlyOnList.length; i++) {
           var isInList = false;
           for(var j = 0; j < isOnListList.length && !isInList; j++)
               isInList = !(isOnListList[j].indexOf(currentlyOnList[i]) < 0);
           if(!isInList)
               tmpRemoveList.push(currentlyOnList[i]);
        }
        //console.log('length: ' + tmpRemoveList.length);
        //console.log('target: ' + JSON.stringify(tmpRemoveList));
	//console.log(JSON.stringify(isOnListList));
        for(var k = 0; k < tmpRemoveList.length; k++) {
           isResettingDoNotDisturb = true;
            gpio.write(tmpRemoveList[k], false, function(err) {
                if(err) throw err; 
                if(this.index == tmpRemoveList.length - 1) {
                    resetWithNew();
                }
                }.bind({index: k})
                );
        }
    }
}

setInterval(checkNewPin, 500);
setInterval(checkOldPin, 1000);
