var express = require('express');
var app = express();

var conf = require('./conf.js');
var control = require('./control.js');
var weather = require('./weather.js');
var sensorValveController = require('./sensorValveController.js');
var timeValveController = require('./timeValveController.js');
var gpioController = require('./gpioController.js');

timeValveController.init(weather, gpioController);
sensorValveController.init(gpioController);

conf.init(app, weather);
control.init(app, sensorValveController, timeValveController);

app.listen(80, () => console.log('Test program listening on port 80!'));
