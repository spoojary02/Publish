# Work_Sprinkler
Web-based firmware for the SAYA sprinkler. Uses node js, but can be called from outside. 

### Functionalities
1. Add/Remove Valves
    * Add valve control by specifying time and other properties
    * Add valve by specifying GPIO pin for sensor
2. Configure System
    * Test location to use
    * Specify Location
    * *Currently Not Supported:* set up wifi

### For test use
1. pull repository from git
2. install Node JS
    * **wget https://nodejs.org/dist/v8.2.1/node-v8.2.1-linux-armv6l.tar.gz**
    * **tar -xvf node-v8.2.1-linux-armv6l.tar.gz**
    * **cd node-v8.2.1-linux-armv6l**
    * **mv /usr/local**
    * Test with **node -v** and **npm -v**. 
3. run with command **sudo node runServer.js**
    * let it set up for 5 seconds or so
4. web interface will show up on **localhost:80/sprinkler** 

