

currentList = [];
gpioOut = null;

function closeAll() {
    //close all GPIO connections
};

function setup() {
    for(var i = 0; i < currentList.length; i++) {
        //set up GPIO pins
    }
};

function reset() {
    closeAll();
    setup();
};

module.exports.alert = function(newList) {
    currentList = newList;
    reset();
};

module.exports.init = function(gpioGiven) {
    gpioOut = gpioGiven;
}
