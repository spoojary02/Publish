var fs = require('fs')
var weather = require('weather-js');
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

const WEATHERREQUESTINTERVAL = 10000; //that's 10 seconds in miliseconds

var LOCATION = '';
var currentWeather = null;

function getWeather() {

    if(LOCATION == ''){
        fs.readFile('location.txt', 'ASCII', function(err, data) {
            if (err) {
                LOCATION = "FILE NOT FOUND";
                //throw err;
            }
            if (require.main === module)
                console.log('getting weather from: ' + data);
            weather.find({search: data, degreeType: 'F'}, function(err, result) {
                if(err) {
                    //console.log(err);
                    setTimeout(getWeather, 1000);
                    return;
                }
                if (require.main === module) {
                    console.log(result[0]);
                }
                currentWeather = result[0];
                });
            });
    } else {
        if (require.main === module)
            console.log('getting weather from: ' + 'Rio de Janeiro, Brazil');
        weather.find({search: 'Rio de Janeiro, Brazil', degreeType: 'F'}, function(err, result) {
            if(err) {
                console.log(err);
                setTimeout(getWeather, 1000);
                return;
            }
            if (require.main === module) {
                console.log(result[0]);
            }
            currentWeather = result[0];
        });
    }
}

function latLongATag(lat, long) {
    ret = '<a href="https://www.google.com/maps/?q=';

    ret += lat + ', ' + long + '">' + lat + ', ' + long +'</a>';

    return(ret);
}


module.exports.getWeather = function() {
    return currentWeather;
};
module.exports.isReady = function() {
    return (currentWeather != null);
};
module.exports.inTheNextDays = function(daycount, weatherTextList) {
    if(daycount > 5) daycount = 5;

    var ret = false;
    
    if(currentWeather != null && (weatherTextList.indexOf(currentWeather.current.skytext) >= 0))
        ret = true;

    for(var i = 0; i <= (daycount - 1) && !ret && currentWeather != null; i++) {
        if(currentWeather != null && weatherTextList.indexOf(currentWeather.forecast[i].skytextday) >= 0) 
            ret = true;
    }

    return ret;
};
module.exports.testLocation = function(location, res) {
    weather.find({search: location, degreeType: 'F'}, function(err, result) {
        if(err) console.log(err);
        
        dataSend = '';
        for(var i = 0; result != undefined && i < result.length; i++)
            dataSend += (i + 1) + '. ' + result[i].location.name + ' == ' +
            latLongATag(result[i].location.lat, result[i].location.long)+ '<br/>\n';
        
        fs.readFile('./conf.html', 'ASCII', function(err, data) {  
            if (err){
                console.log('error loading html while testing location: \n' +
                err);
                return;
            }

            fs.readFile('./location.txt', 'ASCII', function(err, dataCurLoc) {  
                if (err){
                    console.log('error loading location: ' + err);
                    return;
                } 
            
                const dom = new JSDOM(data);
                dom.window.document.querySelector("#currentLocationText").innerHTML = dataCurLoc;
                dom.window.document.querySelector("#locationsText").innerHTML = dataSend;
                res.send(dom.serialize());
            });
        });
    });
};
// Change to setInterval to repeat infinitely
getWeather();
setInterval(getWeather, WEATHERREQUESTINTERVAL);
