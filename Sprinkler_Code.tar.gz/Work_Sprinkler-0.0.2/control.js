var bodyParser = require('body-parser');
var fs = require('fs');
var process = require('process');
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

const CONFIGFILEPATH = './control.html';
const URLPATH = '/';

var sensorValves =  JSON.parse(fs.readFileSync('sensorValves.json', 'ASCII'));
var timeValves = JSON.parse(fs.readFileSync('timeValves.json', 'ASCII'));
if(sensorValves == '' || sensorValves == null)
    sensorValves = [];
if(timeValves == '' || timeValves == null) 
    timeValves = [];

const VALIDPINS = [11, 13, 15, 29, 31, 33, 35, 37, 32, 36, 38, 40];

var sensorValveController = null;
var timeValveController = null;

//HTML manipulating function
function tablulate(inputArray) {
    ret = '<tr>';
    for(var i = 0; i < inputArray.length; i++)
        ret += '<td>' + inputArray[i] + '</td>';
    ret += '<tr>\n'
    return ret;
}

function makeSensorValveTable() {
    sensorValveHTML = '';
    for(var i = 0; i < sensorValves.length; i++) 
        sensorValveHTML += tablulate([sensorValves[i].valveNum, 
            sensorValves[i].sensorNum]);
    return sensorValveHTML;
}

function makeTimeValveTable() {
    timeValvesHTML = '';
    for(var i = 0; i < timeValves.length; i++) {
        timeValvesHTML += tablulate([i,"Zone " + (VALIDPINS.indexOf(parseInt(timeValves[i].valveNum)) + 1), 
            timeValves[i].timeStart, timeValves[i].timeEnd,
            timeValves[i].rainVal, timeValves[i].days]);
    }
    return timeValvesHTML;
}

function standardOutput(res) {
    fs.readFile('./control.html', 'ASCII', function(err, data) {  
        if (err){
            console.log('error loading html while on main sprinkler page\n' +
            err);
            return;
        } 
        
        const dom = new JSDOM(data);
        //dom.window.document.querySelector("#sensorValveList").innerHTML = makeSensorValveTable();
        dom.window.document.querySelector("#timeValveList").innerHTML = makeTimeValveTable();
        res.send(dom.serialize());
    });
}

//JSON save Handler
function saveHandler(options, err) {
    // process.stdin.resume();//so the program will not close instantly
    fs.writeFileSync("./sensorValves.json", JSON.stringify(sensorValves));
    fs.writeFileSync("./timeValves.json", JSON.stringify(timeValves));
    console.log('Current State Saved');
}

//GPIO controller handling
function alertControllers() {
    //sensorValveController.alert(sensorValves);
    timeValveController.alert(timeValves);
}

//valve list handlers
function valveAllowed(valveNum) {
    return (VALIDPINS.indexOf(parseInt(valveNum)) >= 0);
};

function sensorAllowed(sensorNum) {
    return (VALIDPINS.indexOf(parseInt(sensorNum)) >= 0);
};

function addModifySensorValve(req) {
    var isInList = false;
    for(var i = 0; i < sensorValves.length && !isInList; i++) {
        if(sensorValves[i].valveNum == req.body.valveNum) {
            sensorValves[i].sensorNum = req.body.sensorNum;
            isInList = true;
        }
    }
    if(!isInList)
        sensorValves[sensorValves.length] = {
            valveNum: req.body.valveNum,
            sensorNum: req.body.sensorNum
        };
};

function removeSensorValve(req) {
    for(var i = 0; i < sensorValves.length; i++) {
        if(sensorValves[i].valveNum == req.body.valveNum)
            sensorValves.splice(i, 1);
    }
};

function addModifyTimeValve(req) {
    timeValves[timeValves.length] = {
        valveNum:  req.body.valveNum,
        timeStart: req.body.timeStart,
        timeEnd: req.body.timeEnd,
        rainVal: req.body.rainVal,
        days: req.body.tDaysList
    };
}

function removeTimeValve(req) {
    let index = parseInt(req.body.remIndex);
    if(index >= 0 && index < timeValves.length) {
        console.log("Remove Rule: index=" + index);
        timeValves.splice(index, 1);
    } else
        console.log("Remove Index Out of Bounds");
}

//exported modules
module.exports.init = function(app, sensorValveControllerGiven, 
    timeValveControllerGiven, gpio) {

    sensorValveController = sensorValveControllerGiven;
    timeValveController = timeValveControllerGiven;
    alertControllers();
    
    app.use(bodyParser.urlencoded({ extended: true }));     
    app.use(bodyParser.json());

    app.get(URLPATH, function getConfPage(req, res) {
        standardOutput(res);
    });

    app.post(URLPATH, function postProcess(req, res) {
        if(req.body.submit == "Add/Modify Time Valve") {
            if(req.body.valveNum != '' && req.body.timeStart != ''
                && req.body.timeEnd != '' && req.body.rainVal != '' && valveAllowed(req.body.valveNum)) {
                console.log('Add Time Valve: ' + req.body.valveNum + "(Zone " + (VALIDPINS.indexOf(parseInt(req.body.valveNum)) + 1) + ")");
                addModifyTimeValve(req);
            } else {
                console.log('Cannot add rule, missing parameters');
                console.log(JSON.stringify(req.body));
            } 
        } else if(req.body.submit == "Remove Time Valve") {
            removeTimeValve(req)
        } else {
            res.send("Oops, error");
        }
        alertControllers();
        setTimeout(saveHandler, 10);
        standardOutput(res);
    });
}

module.exports.getSensorValves = function() {
    return sensorValves;
};

module.exports.getTimeValves = function() {
    return timeValves;
}




//console.log("ALL IS WELL");
